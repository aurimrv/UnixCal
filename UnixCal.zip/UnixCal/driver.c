#include <stdio.h>

void driver(int tc_number, int argc, char  *argv[])
{
    switch (tc_number)
    {
        case 0:
            dispatch(argc, argv);
    }
}
